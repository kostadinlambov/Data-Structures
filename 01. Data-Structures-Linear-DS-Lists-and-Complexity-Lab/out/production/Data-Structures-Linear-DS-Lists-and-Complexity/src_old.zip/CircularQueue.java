//package circularQueue;

public class CircularQueue<E> {

    private int size;
    private E[] arr;
    private int initialCapacity;
    private int head;
    private int tail;

    public CircularQueue() {
        this(4);
    }

    public CircularQueue(int initialCapacity) {
        this.initialCapacity = initialCapacity;
        this.head = 0;
        this.tail = 0;
        this.size = 0;
        this.arr = (E[]) new Object[this.initialCapacity];
    }

    public int size() {
        return this.size;
    }

    private void setSize(int size) {
        this.size = size;
    }

    public void enqueue(E element) {
        if (this.size >= this.initialCapacity) {
            this.resize();
        }
        int index = (this.tail + this.head) % this.initialCapacity;
        this.arr[index] = element;
        this.tail++;
        this.size++;
    }

    private void resize() {
        this.initialCapacity *= 2;
        E[] newArray = (E[]) new Object[this.initialCapacity];
        this.copyAllElements(newArray);

        this.arr = newArray;


    }

    public E dequeue() {
        if (this.size == 0) {
            throw new IllegalArgumentException();
        }
        E element = this.arr[this.head];
        this.head = (this.head + 1) % this.initialCapacity;
        this.size--;

        return element;
    }

    public E[] toArray() {

        E[] newArray = (E[]) new Object[this.initialCapacity];
        this.copyAllElements(newArray);
        return newArray;

//        // TODO
//        throw new UnsupportedOperationException();
    }

    private void copyAllElements(E[] newArray){
        //int startIndex = 0;
        for (int i = 0; i < this.size ; i++) {
            int index = (i + this.head) % this.arr.length;
            newArray[i] = this.arr[index];
        }
        this.head = 0;
        this.tail = this.size;
        this.arr = newArray;
    }
}
